/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *  \verbatim
 *
 *                 This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                 Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                 All other rights remain with Vector Informatik GmbH.
 *  \endverbatim
 *  -------------------------------------------------------------------------------------------------------------------
 *  LICENSE
 *  -------------------------------------------------------------------------------------------------------------------
 *            Module: Os
 *           Program: MSR_Vector_SLP4
 *          Customer: China Lithium Battery Technology Co., Ltd.
 *       Expiry Date: 2025-08-26
 *  Ordered Derivat.: SAK-TC387QP-160F300S AE
 *    License Scope : The usage is restricted to CBD2200508_D00
 *
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *              File: Os_Stack_Cfg.h
 *   Generation Time: 2026-08-26 14:56:25
 *           Project: last364 - Version 1.0
 *          Delivery: CBD2200508_D00
 *      Tool Version: DaVinci Configurator Classic (beta) 5.25.37 SP2
 *
 *
 *********************************************************************************************************************/

/**********************************************************************************************************************
 ! BETA VERSION                                                                                                       !
 !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 ! This version of DaVinci Configurator Classic and/or the related Basic Software Package is BETA software.               !
 ! BETA Software is basically operable, but not sufficiently tested, verified and/or qualified for use in series      !
 ! production and/or in vehicles operating on public or non-public roads.                                             !
 ! In particular, without limitation, BETA Software may cause unpredictable ECU behavior, may not provide all         !
 ! functions necessary for use in series production and/or may not comply with quality requirements which are         !
 ! necessary according to the state of the art. BETA Software must not be used in series production.                  !
 !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
**********************************************************************************************************************/

#ifndef OS_STACK_CFG_H
# define OS_STACK_CFG_H

/**********************************************************************************************************************
 *  INCLUDES
 *********************************************************************************************************************/

/* AUTOSAR includes */
# include "Std_Types.h"

/**********************************************************************************************************************
 *  GLOBAL CONSTANT MACROS
 *********************************************************************************************************************/

/*! Defines whether stack monitoring is active (STD_ON) or not (STD_OFF). */
# define OS_CFG_STACKMONITORING                  (STD_ON)

/*! Defines whether stack measurement is active (STD_ON) or not (STD_OFF). */
# define OS_CFG_STACKMEASUREMENT                 (STD_OFF)

/* Configured stack sizes (Total: 35840 Byte) */
# define OS_CFG_SIZE_BRSMAINTASK_STACK     (1024u)
# define OS_CFG_SIZE_DEFAULT_APPL_TASK_STACK     (4096u)
# define OS_CFG_SIZE_DEFAULT_BSW_ASYNC_TASK_10MS_STACK     (4096u)
# define OS_CFG_SIZE_MOTORTASK_STACK     (4096u)
# define OS_CFG_SIZE_OSCORE0_ERROR_STACK     (1024u)
# define OS_CFG_SIZE_OSCORE0_INIT_STACK     (1024u)
# define OS_CFG_SIZE_OSCORE0_ISR_CORE_STACK     (1024u)
# define OS_CFG_SIZE_OSCORE0_KERNEL_STACK     (1024u)
# define OS_CFG_SIZE_OSCORE0_SHUTDOWN_STACK     (1024u)
# define OS_CFG_SIZE_OSCORE0_STARTUP_STACK     (1024u)
# define OS_CFG_SIZE_OSCORE0_TASK_PRIO2_STACK     (1024u)
# define OS_CFG_SIZE_OSCORE0_TASK_PRIO4294967295_STACK     (1024u)
# define OS_CFG_SIZE_OSCORE0_TASK_PRIO45_STACK     (1024u)
# define OS_CFG_SIZE_OSCORE0_TASK_PRIO49_STACK     (1024u)
# define OS_CFG_SIZE_OSCORE0_TASK_PRIO50_STACK     (1024u)
# define OS_CFG_SIZE_OSCORE1_ERROR_STACK     (1024u)
# define OS_CFG_SIZE_OSCORE1_INIT_STACK     (1024u)
# define OS_CFG_SIZE_OSCORE1_ISR_CORE_STACK     (1024u)
# define OS_CFG_SIZE_OSCORE1_KERNEL_STACK     (1024u)
# define OS_CFG_SIZE_OSCORE1_SHUTDOWN_STACK     (1024u)
# define OS_CFG_SIZE_OSCORE1_STARTUP_STACK     (1024u)
# define OS_CFG_SIZE_OSCORE1_TASK_PRIO0_STACK     (1024u)
# define OS_CFG_SIZE_OSCORE1_TASK_PRIO20_STACK     (1024u)
# define OS_CFG_SIZE_OSCORE1_TASK_PRIO4294967295_STACK     (1024u)
# define OS_CFG_SIZE_OSCORE1_TASK_PRIO49_STACK     (1024u)
# define OS_CFG_SIZE_OSCORE1_TASK_PRIO50_STACK     (1024u)


/**********************************************************************************************************************
 *  GLOBAL FUNCTION MACROS
 *********************************************************************************************************************/


#endif /* OS_STACK_CFG_H */

/**********************************************************************************************************************
 *  END OF FILE: Os_Stack_Cfg.h
 *********************************************************************************************************************/
