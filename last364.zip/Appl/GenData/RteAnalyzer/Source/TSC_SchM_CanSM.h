/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *  \verbatim
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  \endverbatim
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  TSC_SchM_CanSM.h
 *           Config:  last364.dpa
 *        SW-C Type:  CanSM
 *
 *        Generator:  MICROSAR RTE Generator Version 4.29.0
 *                    RTE Core Version 1.29.0
 *          License:  CBD2200508
 *
 *      Description:  Header of wrapper software component for Bte-based Rte test cases
 *********************************************************************************************************************/
void TSC_CanSM_SchM_Enter_CanSM_CANSM_EXCLUSIVE_AREA_1();
void TSC_CanSM_SchM_Exit_CanSM_CANSM_EXCLUSIVE_AREA_1();
void TSC_CanSM_SchM_Enter_CanSM_CANSM_EXCLUSIVE_AREA_2();
void TSC_CanSM_SchM_Exit_CanSM_CANSM_EXCLUSIVE_AREA_2();
void TSC_CanSM_SchM_Enter_CanSM_CANSM_EXCLUSIVE_AREA_3();
void TSC_CanSM_SchM_Exit_CanSM_CANSM_EXCLUSIVE_AREA_3();
void TSC_CanSM_SchM_Enter_CanSM_CANSM_EXCLUSIVE_AREA_4();
void TSC_CanSM_SchM_Exit_CanSM_CANSM_EXCLUSIVE_AREA_4();
void TSC_CanSM_SchM_Enter_CanSM_CANSM_EXCLUSIVE_AREA_5();
void TSC_CanSM_SchM_Exit_CanSM_CANSM_EXCLUSIVE_AREA_5();
void TSC_CanSM_SchM_Enter_CanSM_CANSM_EXCLUSIVE_AREA_6();
void TSC_CanSM_SchM_Exit_CanSM_CANSM_EXCLUSIVE_AREA_6();
