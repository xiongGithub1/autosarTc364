/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *  \verbatim
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  \endverbatim
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  TSC_SchM_Crc.c
 *           Config:  last364.dpa
 *        SW-C Type:  Crc
 *
 *        Generator:  MICROSAR RTE Generator Version 4.29.0
 *                    RTE Core Version 1.29.0
 *          License:  CBD2200508
 *
 *      Description:  Header of wrapper software component for Bte-based Rte test cases
 *********************************************************************************************************************/
#include "SchM_Crc.h"
#include "TSC_SchM_Crc.h"
void TSC_Crc_SchM_Enter_Crc_CriticalSection(void)
{
  SchM_Enter_Crc_CriticalSection();
}
void TSC_Crc_SchM_Exit_Crc_CriticalSection(void)
{
  SchM_Exit_Crc_CriticalSection();
}
